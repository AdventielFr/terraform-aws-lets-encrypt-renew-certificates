**To describe an audit report for a certificate authority**

The ``describe-certificate-authority-audit-report`` command lists information about your audit report::

  aws acm-pca describe-certificate-authority-audit-report --certificate-authority-arn arn:aws:acm-pca:us-east-1:account:certificate-authority/99999999-8888-7777-6666-555555555555 --audit-report-id 11111111-2222-3333-4444-555555555555