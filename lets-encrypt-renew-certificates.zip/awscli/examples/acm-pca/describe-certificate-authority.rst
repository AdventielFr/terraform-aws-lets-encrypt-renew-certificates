**To describe a private certificate authority**

The ``describe-certificate-authority`` command lists information about your private CA::

  aws acm-pca describe-certificate-authority --certificate-authority-arn arn:aws:acm-pca:us-east-1:account:certificate-authority/12345678-1234-1234-1234-123456789012