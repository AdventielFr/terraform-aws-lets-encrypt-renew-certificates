**To update user details**

This example updates the specified details for the specified user.

Command::

  aws chime update-user --account-id 12a3456b-7c89-012d-3456-78901e23fg45 --user-id 1ab2345c-67de-8901-f23g-45h678901j2k --license-type "Basic"

Output::

  {
    "User": {
        "UserId": "1ab2345c-67de-8901-f23g-45h678901j2k"
    }
  }
